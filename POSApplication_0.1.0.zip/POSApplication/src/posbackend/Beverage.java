package posbackend;

public class Beverage {
    private final double beveragePrice = 1.00;

    public double getBeveragePrice() {
        return beveragePrice;
    }
    
    
    
}
