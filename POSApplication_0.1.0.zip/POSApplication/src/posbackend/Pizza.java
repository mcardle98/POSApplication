package posbackend;

public class Pizza {
    private final Double pizzaPrice = 6.99;

    public Double getPizzaPrice() {
        return pizzaPrice;
    }
    
}
